#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion

flags = 1         

v = 0.5       #Linear velocity initialization
w = 0.0       #Angular velocity initialization
c1 = 0
c2 = 0

regions = {                   # Defining LiDAR regions
        'bright': 0.0  ,
        'fright': 0.0  ,
        'front':  0.0  ,
        'fleft':  0.0  ,
        'bleft':  0.0  ,
}

def laser_callback(msg):                #callback function for LiDAR data
    global regions
    regions = {
        'bright': min(min(msg.ranges[0:20]),3.2)  ,
        'fright': min(min(msg.ranges[40:60]),3.2)  ,
        'front':  min(min(msg.ranges[80:100]),3.2)  ,
        'fleft':  min(min(msg.ranges[120:140]),3.2)  ,
        'bleft':  min(min(msg.ranges[160:180]),3.2)  ,
}

def P_Str(stage):     #function for the proportional controller
    global w
    global regions
    kp1 = -0.08          #0.07
    kp2 = -10.0
    kp3 = -12.5
    if stage == 1:
        w = kp1 * (regions['bright']-regions['bleft'])
    elif stage == 3:
        w = kp2 * (regions['fright']-0.8)
    elif stage == 5:
        w = kp3* (regions['fright']-0.8)



def goStraight():            #function to control the forward motion of the bot i.e. the straight linear motion of the bot
    global v
    global w
    v = 1.0             #1.5
    w = 0.0

def goRight():
    global v
    global w
    v = 0.8             #0.9
    w = -3.0            #2.7


def control_loop():          #control function

    rospy.init_node('ebot_controller')
    pub = rospy.Publisher('/cmd_vel',Twist,queue_size=10)               #setting up publisher
    rospy.Subscriber('/ebot/laser/scan',LaserScan, laser_callback)      #setting up subscriber
    rate =  rospy.Rate(10)

    vel_out = Twist()
    
    # Getting global scope
    global v
    global w
    global flags
    global regions
    global c1
    global c2

    while not rospy.is_shutdown():
        
        c1 = c1 + 1
        if flags == 1 :       #flag 1
            goStraight()
            P_Str(1)          #calling P controller
            vel_out.linear.x = v
            vel_out.angular.z = w - 0.04
            pub.publish(vel_out)
            if (c1 > 50 and regions['bright'] > 2.7) :
                flags = 2

        elif flags == 2:      #flag 2
            c2 = c2 + 1
            goRight()
            vel_out.linear.x = v
            vel_out.angular.z = w
            pub.publish(vel_out)
            if c2 == 24:
                flags = 3

        elif flags == 3 :      #flag 3
            goStraight()
            P_Str(3)
            vel_out.linear.x = v + 0.4
            vel_out.angular.z = w
            pub.publish(vel_out)
            if c1 == 210 or regions['fright'] > 2.7:
                flags = 4

        elif flags == 4:      #flag 4
            goRight()
            vel_out.linear.x = 1.0
            vel_out.angular.z = -1.05
            pub.publish(vel_out)
            if c1 >= 235 and regions['fright']  < 1.5:     #195
                flags = 5

        elif flags == 5:      #flag 5
            goStraight()
            P_Str(5)
            vel_out.linear.x = v + 0.4
            vel_out.angular.z = w
            pub.publish(vel_out)
            if regions['bright'] > 2.8 :
                vel_out.linear.x = 0.0
                vel_out.angular.z = 0.0
                pub.publish(vel_out)
                break

        print("Controller message pushed at {}".format(rospy.get_time()))
        rate.sleep()


if __name__=='__main__':
    try:
        control_loop()
    except rospy.ROSInterruptException:
        pass
